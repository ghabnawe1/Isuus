import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { format } from "date-fns";
import { CalendarIcon, Plane, Bed, Search, User, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { flightRequestSchema, healthInsuranceSchema, type FlightRequest, type HealthInsuranceRequest } from "@/lib/schemas";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { AIRPORTS } from "@/lib/data";
import { useLocation } from "wouter";
import { HeartPulse, PlusCircle } from "lucide-react";

export default function TicketRequestForm() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  const flightForm = useForm<FlightRequest>({
    resolver: zodResolver(flightRequestSchema),
    defaultValues: {
      tripType: "round-trip",
      passengers: 1,
      hasAdditionalPassengers: false,
    },
  });

  const insuranceForm = useForm<HealthInsuranceRequest>({
    resolver: zodResolver(healthInsuranceSchema),
    defaultValues: {
      durationDays: 30,
    },
  });

  const onFlightSubmit = (data: FlightRequest) => {
    toast({
      title: "تم استلام الطلب",
      description: `جاري معالجة طلب الطيران الخاص بك...`,
    });
    setLocation("/status");
  };

  const onInsuranceSubmit = (data: HealthInsuranceRequest) => {
    toast({
      title: "تم استلام الطلب",
      description: `جاري معالجة طلب التأمين الصحي...`,
    });
    setLocation("/status");
  };

  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
      <Tabs defaultValue="flight" className="w-full">
        <div className="bg-gray-50/50 border-b px-6 pt-4">
          <TabsList className="bg-transparent p-0 h-auto gap-6 justify-start">
            <TabsTrigger 
              value="flight" 
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-2 pb-3 text-base font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              <Plane className="w-4 h-4 mr-2" />
              الطيران
            </TabsTrigger>
            <TabsTrigger 
              value="insurance" 
              className="data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-primary data-[state=active]:text-primary rounded-none px-2 pb-3 text-base font-medium text-muted-foreground hover:text-primary transition-colors"
            >
              <HeartPulse className="w-4 h-4 mr-2" />
              التأمين الصحي
            </TabsTrigger>
          </TabsList>
        </div>

        <div className="p-6 md:p-8">
          <TabsContent value="flight" className="mt-0">
            <Form {...flightForm}>
              <form onSubmit={flightForm.handleSubmit(onFlightSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <FormField
                    control={flightForm.control}
                    name="tripType"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-4">
                        <FormLabel>نوع الرحلة</FormLabel>
                        <FormControl>
                          <select 
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            {...field}
                          >
                            <option value="one-way">اتجاه واحد</option>
                            <option value="round-trip">ذهاب وعودة</option>
                            <option value="multi-city">مدن متعددة</option>
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {/* ... AIRPORTS FIELDS ... */}
                  <FormField
                    control={flightForm.control}
                    name="from"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>من</FormLabel>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <FormControl>
                            <select 
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-9"
                              {...field}
                            >
                              <option value="">اختر المطار</option>
                              {[...AIRPORTS].sort((a, b) => a.city.localeCompare(b.city)).map(airport => (
                                <option key={airport.code} value={airport.code}>
                                  {airport.city} ({airport.code}) - {airport.country}
                                </option>
                              ))}
                            </select>
                          </FormControl>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="to"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>إلى</FormLabel>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                          <FormControl>
                            <select 
                              className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 pl-9"
                              {...field}
                            >
                              <option value="">اختر المطار</option>
                              {[...AIRPORTS].sort((a, b) => a.city.localeCompare(b.city)).map(airport => (
                                <option key={airport.code} value={airport.code}>
                                  {airport.city} ({airport.code}) - {airport.country}
                                </option>
                              ))}
                            </select>
                          </FormControl>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  {/* ... DATES ... */}
                  <FormField
                    control={flightForm.control}
                    name="departureDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>تاريخ المغادرة</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>اختر التاريخ</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) =>
                                date < new Date()
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="returnDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <FormLabel>تاريخ العودة (اختياري)</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>اختر التاريخ</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) =>
                                date < new Date()
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="passengers"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>عدد المسافرين</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min={1} 
                            max={9} 
                            {...field} 
                            onChange={e => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="passportNumber"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>رقم الجواز</FormLabel>
                        <FormControl>
                          <Input placeholder="أدخل رقم الجواز" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>الاسم الأول</FormLabel>
                        <FormControl>
                          <Input placeholder="كما هو في الجواز" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>الاسم الأخير</FormLabel>
                        <FormControl>
                          <Input placeholder="كما هو في الجواز" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="hasAdditionalPassengers"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-4 flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            هل هناك مسافرين آخرين؟
                          </FormLabel>
                          <FormDescription>
                            قم بتحديد هذا الخيار إذا كنت ترغب في إضافة بيانات مسافرين إضافيين للطلب.
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  {/* ... CONTACT ... */}
                  <FormField
                    control={flightForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>البريد الإلكتروني</FormLabel>
                        <FormControl>
                          <Input placeholder="عنوان إرسال التذكرة" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="countryCode"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-1">
                        <FormLabel>كود الدولة</FormLabel>
                        <FormControl>
                          <Input placeholder="+1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={flightForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-1">
                        <FormLabel>رقم الهاتف</FormLabel>
                        <FormControl>
                          <Input placeholder="234 567 890" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <Button type="submit" size="lg" className="w-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all">
                  طلب حجز الطيران <span className="ml-2">→</span>
                </Button>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="insurance" className="mt-0">
            <Form {...insuranceForm}>
              <form onSubmit={insuranceForm.handleSubmit(onInsuranceSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <FormField
                    control={insuranceForm.control}
                    name="passportNumber"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-4">
                        <FormLabel>رقم الجواز</FormLabel>
                        <FormControl>
                          <Input placeholder="أدخل رقم الجواز لطلب التأمين" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>الاسم الأول</FormLabel>
                        <FormControl>
                          <Input placeholder="كما هو في الجواز" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>الاسم الأخير</FormLabel>
                        <FormControl>
                          <Input placeholder="كما هو في الجواز" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="startDate"
                    render={({ field }) => (
                      <FormItem className="flex flex-col col-span-1 lg:col-span-2">
                        <FormLabel>تاريخ بدء التأمين</FormLabel>
                        <Popover>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <Button
                                variant={"outline"}
                                className={cn(
                                  "w-full pl-3 text-left font-normal",
                                  !field.value && "text-muted-foreground"
                                )}
                              >
                                {field.value ? (
                                  format(field.value, "PPP")
                                ) : (
                                  <span>اختر التاريخ</span>
                                )}
                                <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                              </Button>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0" align="start">
                            <Calendar
                              mode="single"
                              selected={field.value}
                              onSelect={field.onChange}
                              disabled={(date) =>
                                date < new Date()
                              }
                              initialFocus
                            />
                          </PopoverContent>
                        </Popover>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="durationDays"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>مدة التأمين (بالأيام)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            {...field} 
                            onChange={e => field.onChange(parseInt(e.target.value))}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-2">
                        <FormLabel>البريد الإلكتروني</FormLabel>
                        <FormControl>
                          <Input placeholder="عنوان إرسال وثيقة التأمين" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="countryCode"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-1">
                        <FormLabel>الكود</FormLabel>
                        <FormControl>
                          <Input placeholder="+1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={insuranceForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem className="col-span-1 lg:col-span-1">
                        <FormLabel>الهاتف</FormLabel>
                        <FormControl>
                          <Input placeholder="234 567 890" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <Button type="submit" size="lg" className="w-full text-lg font-semibold shadow-lg hover:shadow-xl transition-all">
                  طلب التأمين الصحي <span className="ml-2">→</span>
                </Button>
              </form>
            </Form>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}

