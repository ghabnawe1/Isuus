import { ShieldCheck, Clock, FileCheck, Globe2, UserCheck, Headset } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";

export default function Features() {
  const { t, language } = useLanguage();
  
  const features = [
    {
      icon: ShieldCheck,
      title: language === "ar" ? "قابلة للتحقق 100%" : "100% Verifiable",
      description: language === "ar" ? "يأتي كل حجز برمز PNR فريد قابل للتحقق على موقع شركة الطيران." : "Every reservation comes with a unique PNR code verifiable on the airline's website."
    },
    {
      icon: Clock,
      title: language === "ar" ? "تسليم فوري" : "Instant Delivery",
      description: language === "ar" ? "استلم مستنداتك خلال 10-60 دقيقة مباشرة إلى بريدك الإلكتروني." : "Receive your documents within 10-60 minutes directly to your email inbox."
    },
    {
      icon: FileCheck,
      title: language === "ar" ? "مقبول للتأشيرة" : "Visa Accepted",
      description: language === "ar" ? "مصمم خصيصاً لطلبات التأشيرة ومقبول من قبل السفارات والقنصليات عالمياً." : "Designed specifically for visa applications. Accepted by embassies and consulates worldwide."
    },
    {
      icon: Globe2,
      title: language === "ar" ? "تغطية عالمية" : "Global Coverage",
      description: language === "ar" ? "نعمل مع كبرى شركات الطيران والفنادق حول العالم لنوفر لك أفضل المسارات." : "We work with major airlines and hotel chains across the globe to get you the best routes."
    },
    {
      icon: UserCheck,
      title: language === "ar" ? "خدمة الوساطة" : "Intermediary Service",
      description: language === "ar" ? "نتعامل مع عملية الحجز مع المزودين لنوفر عليك المخاطرة بأموالك الخاصة." : "We handle the booking process with the providers so you don't have to risk your own funds."
    },
    {
      icon: Headset,
      title: language === "ar" ? "دعم 24/7" : "24/7 Support",
      description: language === "ar" ? "خبراء السفر لدينا متاحون دائماً للمساعدة في أي تغييرات أو استفسارات." : "Our travel experts are always available to help with any changes or questions."
    }
  ];

  return (
    <section id="features" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{t("nav.howItWorks")}</h2>
          <p className="text-lg text-gray-600">
            {language === "ar" ? "نحن نبسط عملية طلب التأشيرة الخاصة بك من خلال توفير مستندات سفر قابلة للتحقق خالية من المخاطر." : "We simplify your visa application process by providing risk-free verifiable travel documents."}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={index} 
              className="group p-8 rounded-2xl border border-gray-100 bg-gray-50/50 hover:bg-white hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-primary transition-colors">
                <feature.icon className="w-6 h-6 text-primary group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
