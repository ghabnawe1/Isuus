import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/lib/LanguageContext";

export default function Pricing() {
  const { t, language } = useLanguage();
  
  const plans = [
    {
      name: language === "ar" ? "حجز طيران" : "Flight Reservation",
      price: "15",
      description: language === "ar" ? "مثالي لطلبات التأشيرة وإثبات السفر المستقبلي." : "Perfect for visa applications and proof of onward travel.",
      features: language === "ar" ? [
        "مسار طيران قابل للتحقق",
        "صالح لمدة 48 ساعة إلى 14 يوماً",
        "مقبول من السفارات",
        "تحميل PDF فوري",
        "دعم 24/7"
      ] : [
        "Verifiable Flight Itinerary",
        "Valid for 48 Hours to 14 Days",
        "Accepted by Embassies",
        "Instant PDF Download",
        "24/7 Support"
      ],
      highlight: false
    },
    {
      name: language === "ar" ? "عرض الباقة" : "Bundle Deal",
      price: "25",
      description: language === "ar" ? "باقة كاملة تشمل حجز طيران وتأمين صحي." : "Complete package including both flight and health insurance.",
      features: language === "ar" ? [
        "حجز طيران + تأمين صحي",
        "صالح لمدة 48 ساعة إلى 14 يوماً",
        "معالجة ذات أولوية",
        "مقبول من السفارات",
        "تحميل PDF فوري",
        "دعم 24/7"
      ] : [
        "Flight + Health Insurance",
        "Valid for 48 Hours to 14 Days",
        "Priority Processing",
        "Accepted by Embassies",
        "Instant PDF Download",
        "24/7 Support"
      ],
      highlight: true
    },
    {
      name: language === "ar" ? "تأمين صحي" : "Health Insurance",
      price: "15",
      description: language === "ar" ? "تأمين صحي للسفر معتمد لطلبات التأشيرة." : "Approved travel health insurance for visa applications.",
      features: language === "ar" ? [
        "تأمين صحي قابل للتحقق",
        "صالح لطلبات التأشيرة",
        "تواريخ قابلة للتخصيص",
        "تحميل PDF فوري",
        "دعم 24/7"
      ] : [
        "Verifiable Health Insurance",
        "Valid for Visa Application",
        "Customizable Dates",
        "Instant PDF Download",
        "24/7 Support"
      ],
      highlight: false
    }
  ];

  return (
    <section id="pricing" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{t("pricing.title")}</h2>
          <p className="text-lg text-gray-600">
            {t("pricing.subtitle")}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`relative rounded-2xl p-8 ${
                plan.highlight 
                  ? "bg-white border-2 border-primary shadow-2xl scale-105 z-10" 
                  : "bg-white border border-gray-100 shadow-lg hover:shadow-xl transition-shadow"
              }`}
            >
              {plan.highlight && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white px-4 py-1 rounded-full text-sm font-bold tracking-wide">
                  {language === "ar" ? "الأكثر طلباً" : "MOST POPULAR"}
                </div>
              )}
              
              <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
              <p className="text-gray-500 text-sm mb-6">{plan.description}</p>
              
              <div className="flex items-baseline mb-8">
                <span className="text-4xl font-extrabold text-gray-900">${plan.price}</span>
                <span className="text-gray-500 ml-2">/ {language === "ar" ? "مستند" : "document"}</span>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, i) => (
                  <li key={i} className="flex items-start gap-3 text-gray-600">
                    <Check className="w-5 h-5 text-teal-500 shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button 
                className={`w-full text-lg h-12 ${
                  plan.highlight ? "bg-primary hover:bg-blue-700" : "bg-gray-900 hover:bg-gray-800"
                }`}
              >
                {language === "ar" ? "ابدأ الآن" : "Get Started"}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
