import { Link } from "wouter";
import { Plane, Menu, X, MessageCircle, Globe } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useLanguage } from "@/lib/LanguageContext";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { language, setLanguage, t } = useLanguage();

  const NavLinks = () => (
    <>
      <a href="#features" className="text-sm font-medium hover:text-primary transition-colors">{t("nav.howItWorks")}</a>
      <a href="#pricing" className="text-sm font-medium hover:text-primary transition-colors">{t("nav.pricing")}</a>
      <a href="#faq" className="text-sm font-medium hover:text-primary transition-colors">{t("nav.faq")}</a>
      <a href="#contact" className="text-sm font-medium hover:text-primary transition-colors">{t("nav.contact")}</a>
    </>
  );

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center gap-2">
            <div className="bg-primary p-1.5 rounded-lg">
              <Plane className="h-5 w-5 text-white transform -rotate-45" />
            </div>
            <span className="font-heading font-bold text-xl tracking-tight text-primary">SkyBridge</span>
          </a>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <NavLinks />
          
          <div className="flex items-center gap-4 border-l pl-8 mr-4 rtl:border-l-0 rtl:pl-0 rtl:border-r rtl:pr-8 rtl:ml-4">
            <Button 
              variant="ghost" 
              size="sm" 
              className="flex items-center gap-2"
              onClick={() => setLanguage(language === "ar" ? "en" : "ar")}
            >
              <Globe className="h-4 w-4" />
              {language === "ar" ? "English" : "العربية"}
            </Button>
            
            <Button variant="outline" className="flex items-center gap-2 border-green-500 text-green-600 hover:bg-green-50" asChild>
              <a href="https://wa.me/1234567890" target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-4 w-4" /> {t("nav.whatsapp")}
              </a>
            </Button>
            <Button size="sm" className="font-semibold shadow-md hover:shadow-lg transition-all">
              {t("nav.checkStatus")}
            </Button>
          </div>
        </div>

        {/* Mobile Nav */}
        <div className="md:hidden">
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <div className="flex flex-col gap-6 mt-10">
                <NavLinks />
                <Button className="w-full">Check Status</Button>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </nav>
  );
}
