import { useLocation } from "wouter";
import { CheckCircle2, Clock, CreditCard, ExternalLink, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Navbar from "@/components/layout/Navbar";

export default function BookingStatus() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Status Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-blue-100 mb-4">
              <Clock className="h-10 w-10 text-primary animate-pulse" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Booking Request Received</h1>
            <p className="text-gray-600">Your reservation for <span className="font-semibold text-primary">SkyBridge-9823</span> is currently <span className="text-orange-600 font-bold uppercase tracking-wider">Awaiting Payment</span>.</p>
          </div>

          {/* Payment Card */}
          <Card className="border-2 border-primary shadow-2xl overflow-hidden">
            <CardHeader className="bg-primary text-white p-6">
              <CardTitle className="flex items-center gap-2 text-xl">
                <CreditCard className="h-6 w-6" /> Complete Your Payment
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8 space-y-6">
              <div className="flex justify-between items-center pb-6 border-b">
                <span className="text-gray-600">Total Amount Due</span>
                <span className="text-3xl font-bold text-gray-900">$25.00</span>
              </div>

              <div className="space-y-4">
                <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">Select Payment Method</p>
                
                {/* Stripe Button */}
                <Button className="w-full h-14 text-lg font-bold bg-[#635BFF] hover:bg-[#5851e5] text-white flex items-center justify-center gap-3 group transition-all">
                  Pay with <span className="font-extrabold tracking-tighter italic">Stripe</span>
                  <ExternalLink className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>

                {/* PayPal Button */}
                <Button variant="outline" className="w-full h-14 text-lg font-bold border-2 border-[#0070ba] text-[#0070ba] hover:bg-[#0070ba]/5 flex items-center justify-center gap-3 group transition-all">
                  Pay with <span className="font-extrabold italic">PayPal</span>
                  <ExternalLink className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>
              </div>

              <div className="pt-4 flex items-center justify-center gap-2 text-sm text-gray-400">
                <ShieldCheck className="h-4 w-4" />
                Encrypted & Secure Transaction
              </div>
            </CardContent>
          </Card>

          {/* Next Steps */}
          <div className="bg-white rounded-xl p-8 border shadow-sm">
            <h3 className="font-bold text-gray-900 mb-4">What happens next?</h3>
            <ul className="space-y-4 text-gray-600">
              <li className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-50 text-primary flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">1</div>
                <p>Once payment is confirmed, our automated agent reserves your ticket with the airline.</p>
              </li>
              <li className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-50 text-primary flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">2</div>
                <p>You will receive a verifiable PNR code via email within 10-60 minutes.</p>
              </li>
              <li className="flex gap-3">
                <div className="w-6 h-6 rounded-full bg-blue-50 text-primary flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">3</div>
                <p>Use your PNR to verify your booking directly on the airline's official website.</p>
              </li>
            </ul>
          </div>

          <div className="text-center pt-4">
            <Button variant="ghost" onClick={() => setLocation("/")}>
              Cancel and Return Home
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
