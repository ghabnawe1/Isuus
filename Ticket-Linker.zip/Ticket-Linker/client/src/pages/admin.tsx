import { useState } from "react";
import { LayoutDashboard, Users, Ticket, Settings, ArrowLeft, HeartPulse } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { INVESTMENT_FUNDS } from "@/lib/data";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-primary text-white p-6 flex flex-col">
        <div className="flex items-center gap-2 mb-10">
          <div className="bg-white p-1 rounded">
            <Ticket className="h-5 w-5 text-primary" />
          </div>
          <span className="font-heading font-bold text-xl">SkyBridge Admin</span>
        </div>
        
        <nav className="space-y-2 flex-1">
          <button 
            onClick={() => setActiveTab("overview")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === "overview" ? "bg-white/20" : "hover:bg-white/10"}`}
          >
            <LayoutDashboard className="h-5 w-5" /> نظرة عامة
          </button>
          <button 
            onClick={() => setActiveTab("requests")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === "requests" ? "bg-white/20" : "hover:bg-white/10"}`}
          >
            <Users className="h-5 w-5" /> الطلبات
          </button>
          <button 
            onClick={() => setActiveTab("insurance")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === "insurance" ? "bg-white/20" : "hover:bg-white/10"}`}
          >
            <HeartPulse className="h-5 w-5" /> التأمين الصحي
          </button>
          <button 
            onClick={() => setActiveTab("settings")}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${activeTab === "settings" ? "bg-white/20" : "hover:bg-white/10"}`}
          >
            <Settings className="h-5 w-5" /> الإعدادات
          </button>
        </nav>

        <Button variant="ghost" className="text-white hover:bg-white/10 justify-start" asChild>
          <a href="/"><ArrowLeft className="h-4 w-4 mr-2" /> Back to Site</a>
        </Button>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8">
        <header className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 capitalize">{activeTab}</h1>
        </header>

        {activeTab === "overview" && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,284</div>
                <p className="text-xs text-green-500">+12% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Pending Approval</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24</div>
                <p className="text-xs text-blue-500">Needs agent review</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$32,400</div>
                <p className="text-xs text-green-500">+8% from last month</p>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "insurance" && (
          <Card>
            <CardHeader>
              <CardTitle>طلبات التأمين الصحي الأخيرة</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="divide-y">
                {[1, 2, 3].map((_, i) => (
                  <div key={i} className="py-4 flex justify-between items-center">
                    <div>
                      <p className="font-bold">طلب تأمين #{1000 + i}</p>
                      <p className="text-sm text-gray-500">مسافر: أحمد محمد • المدة: 30 يوم</p>
                    </div>
                    <Button size="sm" variant="outline">عرض التفاصيل</Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
