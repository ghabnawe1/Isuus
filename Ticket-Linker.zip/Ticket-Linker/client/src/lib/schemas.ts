import { z } from "zod";

export const flightRequestSchema = z.object({
  tripType: z.enum(["one-way", "round-trip", "multi-city"]),
  from: z.string().min(1, "Origin is required"),
  to: z.string().min(1, "Destination is required"),
  departureDate: z.date({ required_error: "Departure date is required" }),
  returnDate: z.date().optional(),
  passengers: z.number().min(1).max(9),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(5, "Phone number is required"),
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  countryCode: z.string().min(1, "Country code is required"),
  passportNumber: z.string().min(5, "Passport number is required"),
  hasAdditionalPassengers: z.boolean().default(false),
});

export const healthInsuranceSchema = z.object({
  firstName: z.string().min(2, "First name is required"),
  lastName: z.string().min(2, "Last name is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().min(5, "Phone number is required"),
  countryCode: z.string().min(1, "Country code is required"),
  passportNumber: z.string().min(5, "Passport number is required"),
  startDate: z.date({ required_error: "Start date is required" }),
  durationDays: z.number().min(1),
});

export type FlightRequest = z.infer<typeof flightRequestSchema>;
export type HealthInsuranceRequest = z.infer<typeof healthInsuranceSchema>;
