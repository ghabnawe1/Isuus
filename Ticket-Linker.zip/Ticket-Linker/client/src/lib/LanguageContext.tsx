import React, { createContext, useContext, useState, ReactNode } from "react";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  ar: {
    "nav.howItWorks": "كيف يعمل",
    "nav.pricing": "الأسعار",
    "nav.faq": "الأسئلة الشائعة",
    "nav.contact": "اتصل بنا",
    "nav.checkStatus": "تحقق من الحالة",
    "nav.whatsapp": "واتساب",
    "hero.title": "احصل على تأشيرتك مع مسارات سفر موثوقة",
    "hero.subtitle": "نحن نعمل كوسيط موثوق لتوفير حجوزات طيران وفنادق قابلة للتحقق لطلبات التأشيرة وإثبات السفر المستقبلي. سريع وآمن ومقبول عالمياً.",
    "hero.trusted": "موثوق من قبل أكثر من 50,000 مسافر",
    "hero.feature1": "صالح للتأشيرة",
    "hero.feature2": "رمز PNR قابل للتحقق",
    "hero.feature3": "التسليم في 10-60 دقيقة",
    "form.flight": "الطيران",
    "form.insurance": "التأمين الصحي",
    "form.tripType": "نوع الرحلة",
    "form.oneWay": "اتجاه واحد",
    "form.roundTrip": "ذهاب وعودة",
    "form.multiCity": "مدن متعددة",
    "form.from": "من",
    "form.to": "إلى",
    "form.departure": "تاريخ المغادرة",
    "form.return": "تاريخ العودة (اختياري)",
    "form.passengers": "عدد المسافرين",
    "form.passport": "رقم الجواز",
    "form.firstName": "الاسم الأول",
    "form.lastName": "الاسم الأخير",
    "form.email": "البريد الإلكتروني",
    "form.countryCode": "كود الدولة",
    "form.phone": "رقم الهاتف",
    "form.additionalPassengers": "هل هناك مسافرين آخرين؟",
    "form.submitFlight": "طلب حجز الطيران",
    "form.submitInsurance": "طلب التأمين الصحي",
    "form.insuranceStart": "تاريخ بدء التأمين",
    "form.duration": "مدة التأمين (بالأيام)",
    "pricing.title": "أسعار بسيطة وشفافة",
    "pricing.subtitle": "لا توجد رسوم خفية. ادفع فقط مقابل المستندات التي تحتاجها.",
    "footer.rights": "جميع الحقوق محفوظة."
  },
  en: {
    "nav.howItWorks": "How it Works",
    "nav.pricing": "Pricing",
    "nav.faq": "FAQ",
    "nav.contact": "Contact",
    "nav.checkStatus": "Check Status",
    "nav.whatsapp": "WhatsApp",
    "hero.title": "Secure Your Visa with Verifiable Itineraries",
    "hero.subtitle": "We act as your trusted intermediary to provide verifiable flight and hotel reservations for visa applications and proof of onward travel. fast, secure, and accepted worldwide.",
    "hero.trusted": "Trusted by over 50,000 travelers",
    "hero.feature1": "Valid for Visa",
    "hero.feature2": "Verifiable PNR",
    "hero.feature3": "Delivered in 10-60 min",
    "form.flight": "Flights",
    "form.insurance": "Health Insurance",
    "form.tripType": "Trip Type",
    "form.oneWay": "One-Way",
    "form.roundTrip": "Round-Trip",
    "form.multiCity": "Multi-City",
    "form.from": "From",
    "form.to": "To",
    "form.departure": "Departure Date",
    "form.return": "Return Date (Optional)",
    "form.passengers": "Passengers",
    "form.passport": "Passport Number",
    "form.firstName": "First Name",
    "form.lastName": "Last Name",
    "form.email": "Email Address",
    "form.countryCode": "Code",
    "form.phone": "Phone Number",
    "form.additionalPassengers": "Any additional passengers?",
    "form.submitFlight": "Get Flight Reservation",
    "form.submitInsurance": "Get Health Insurance",
    "form.insuranceStart": "Insurance Start Date",
    "form.duration": "Duration (Days)",
    "pricing.title": "Simple, Transparent Pricing",
    "pricing.subtitle": "No hidden fees. Pay only for the documents you need.",
    "footer.rights": "All rights reserved."
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("ar");

  const t = (key: string) => {
    return translations[language][key as keyof typeof translations["en"]] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      <div dir={language === "ar" ? "rtl" : "ltr"}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
